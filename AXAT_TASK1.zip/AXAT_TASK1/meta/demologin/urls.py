from django.contrib import admin
from django.urls import path
from . import views


urlpatterns = [
    path('home', views.index,name = "home"),
    path("save_dtls",views.doc_image_view,name = "signup")
]