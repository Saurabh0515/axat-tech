from django.db import models

# Create your models here.
class document(models.Model):
    email = models.CharField(max_length=150)
    password =  models.CharField(max_length=100)
    doc_img_path = models.ImageField(upload_to='images/')