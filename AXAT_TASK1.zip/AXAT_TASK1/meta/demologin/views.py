# from http.client import HTTPResponse
# from email.mime import image
from django.http import HttpResponse
from django.shortcuts import render,redirect
from .models import *
# Create your views here.
def index (request):
    return render(request,'home.html')



  
# Create your views here.
def doc_image_view(request):
  
    if request.method == 'POST'  :
        im = request.POST.get('img')
        email = request.POST.get('email')
        password = request.POST.get('psw')
        print(im)
        
        save_doc = document(email=email,password =password,doc_img_path=im)
        save_doc.save()
        
        return redirect('home')
        
    return HttpResponse("hello")
  
      

  
  